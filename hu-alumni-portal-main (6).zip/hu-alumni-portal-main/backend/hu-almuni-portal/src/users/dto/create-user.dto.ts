export class createUserDTO {
  email: string;
  firstName: string;
  lastName: string;
}
