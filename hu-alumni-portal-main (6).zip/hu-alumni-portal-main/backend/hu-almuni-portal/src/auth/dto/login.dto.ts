export class loginDTO {
    email : string
    password : string
}