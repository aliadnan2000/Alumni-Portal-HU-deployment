import { User } from "src/users/user.schema";

export class signupDTO extends User {
    
}