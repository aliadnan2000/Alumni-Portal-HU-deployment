import axios from "axios";

export default client = axios.create({
    baseURL : "http://localhost:5000"
});