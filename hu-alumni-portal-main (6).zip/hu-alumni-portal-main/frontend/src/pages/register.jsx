export const register = () => {
    return(
        <>
        register
        </>
    )
}